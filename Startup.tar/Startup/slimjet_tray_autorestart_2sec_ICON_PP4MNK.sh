#!/bin/sh
# Slimjet portable en RAM + KDocker + reinicio rápido al cerrar
# Icono personalizado fijo
# by pp4mnk

LAUNCHER="/files/portable/Slimjet-portable64/RUN-streaming-PP4MNK"
ICON="/usr/share/icons/slimjetuktransp.png"
LOG="/tmp/slimjet-startup-pp4mnk.log"

sleep 5

[ -f "$LAUNCHER" ] || exit 1
[ -f "$ICON" ] || echo "$(date): AVISO: no existe $ICON" >> "$LOG"
command -v kdocker >/dev/null 2>&1 || exit 1

while true; do
    echo "$(date): iniciando Slimjet" >> "$LOG"

    # -i fija el icono personalizado de KDocker
    kdocker -o -q -i "$ICON" sh "$LAUNCHER" >>"$LOG" 2>&1 &

    n=0
    while ! pgrep -x slimjet >/dev/null 2>&1; do
        sleep 0.5
        n=$((n + 1))
        [ "$n" -ge 40 ] && break
    done

    while pgrep -x slimjet >/dev/null 2>&1; do
        sleep 0.5
    done

    echo "$(date): Slimjet cerrado; reiniciando..." >> "$LOG"
    sleep 0.5
done
