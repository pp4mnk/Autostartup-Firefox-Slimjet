#!/bin/sh
# ==========================================
# PP4MNK FIREFOX RAM LAUNCHER v2
# EasyOS / Puppy friendly
# Cache/TMP en RAM · Perfil persistente
# ==========================================

HERE="/files/portable/Firefox-portable64"

BIN="$HERE/firefox64/firefox"

if [ ! -x "$BIN" ]; then
    echo "ERROR: Firefox binary not found:"
    echo "$BIN"
    echo ""
    echo "Busca la ruta real con:"
    echo "find $HERE -type f -name firefox"
    exit 1
fi

PROFILE="$HERE/profile"

RAMBASE="/dev/shm/firefox-pp4mnk"
CACHE="$RAMBASE/cache"
TMP="$RAMBASE/tmp"

mkdir -p "$PROFILE" "$CACHE" "$TMP"

export TMPDIR="$TMP"
export TEMP="$TMP"
export TMP="$TMP"

echo "[PP4MNK] Firefox RAM launcher"
echo "[PP4MNK] Binary : $BIN"
echo "[PP4MNK] Profile: $PROFILE"
echo "[PP4MNK] Cache  : $CACHE"
echo "[PP4MNK] Temp   : $TMP"
PREFS="$PROFILE/user.js"

PREFS="$PROFILE/user.js"

cat > "$PREFS" <<EOF
user_pref("browser.cache.disk.enable", true);
user_pref("browser.cache.disk.parent_directory", "$CACHE");
user_pref("browser.cache.memory.enable", true);
EOF

exec "$BIN" \
  -profile "$PROFILE" \
  -no-remote \
  "$@"