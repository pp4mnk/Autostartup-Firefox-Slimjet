#!/bin/sh
#
# PP4MNK SLIMJET RAM - FINAL
# EasyOS Excalibur
# Optimizado para Intel Core i5-680 + Intel HD Ironlake + 12 GB RAM
#

# ============================================================
# RUTAS
# ============================================================

SLIMJET_RUN="/files/portable/Slimjet-portable64/RUN-PP4MNK"

RAM_BASE="/dev/shm/pp4mnk-browsers/slimjet"

CACHE_DIR="$RAM_BASE/cache"
GPU_CACHE_DIR="$RAM_BASE/gpu-cache"
TMP_DIR="$RAM_BASE/tmp"
PROFILE_DIR="$RAM_BASE/streaming-profile"
RUNTIME_DIR="$RAM_BASE/runtime"


# ============================================================
# COMPROBACIONES
# ============================================================

if [ ! -x "$SLIMJET_RUN" ]; then
    echo "ERROR: No se encuentra:"
    echo "$SLIMJET_RUN"
    exit 1
fi


# ============================================================
# CREAR ESTRUCTURA EN RAM
# ============================================================

mkdir -p \
    "$CACHE_DIR" \
    "$GPU_CACHE_DIR" \
    "$TMP_DIR" \
    "$PROFILE_DIR" \
    "$RUNTIME_DIR"

chmod 700 "$RUNTIME_DIR" 2>/dev/null


# ============================================================
# TEMPORALES Y CACHE EN RAM
# ============================================================

export TMPDIR="$TMP_DIR"
export TEMP="$TMP_DIR"
export TMP="$TMP_DIR"

export XDG_CACHE_HOME="$CACHE_DIR"
export XDG_RUNTIME_DIR="$RUNTIME_DIR"


# ============================================================
# INTEL HD IRONLAKE
#
# iHD no es el driver correcto para esta GPU.
# i965 ha sido comprobado mediante vainfo.
# ============================================================

export LIBVA_DRIVER_NAME=i965


# ============================================================
# LANZAR SLIMJET
# ============================================================

exec nice -n -10 ionice -c2 -n0 \
    "$SLIMJET_RUN" \
    --user-data-dir="$PROFILE_DIR" \
    --disk-cache-dir="$CACHE_DIR" \
    --gpu-disk-cache-dir="$GPU_CACHE_DIR" \
    --disk-cache-size=536870912 \
    --media-cache-size=268435456 \
    --enable-gpu-rasterization \
    --enable-accelerated-video-decode \
    --enable-zero-copy \
    --enable-oop-rasterization \
    --enable-quic \
    --disable-background-timer-throttling \
    --disable-backgrounding-occluded-windows \
    --disable-renderer-backgrounding \
    --disable-domain-reliability \
    --disable-breakpad \
    --disable-crash-reporter \
    --disable-logging \
    --disable-session-crashed-bubble \
    --no-first-run \
    --no-default-browser-check \
    --password-store=basic \
    "$@"
```